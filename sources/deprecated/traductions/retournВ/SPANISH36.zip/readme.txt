At the moment, use the pictures in English. Till I've a computer with
Windows in Spanish. The users will perfectly understand all the
explanations.

also, I need a compiled spanish version of cracklock, to take the images
from cracklock in spanish.
